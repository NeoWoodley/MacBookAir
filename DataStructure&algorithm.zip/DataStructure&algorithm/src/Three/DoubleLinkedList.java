package Three;

public class DoubleLinkedList {
	DoubleNode head=new DoubleNode();
	DoubleNode tail=null;

	int size;

	/**
	 * 在链表尾部添加结点
	 * @param newNode  要添加的新结点
	 */
	public void addNode(DoubleNode newNode) {

	}

	public void insertByIndex(DoubleNode newNode, int index) {

	}

	public void deleteByIndex(int index) {

	}


}
